from typing import Optional
from fastapi import FastAPI, Request, Form, Response, Query
from pydantic import BaseModel
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from ipywidgets.embed import embed_minimal_html
import uvicorn

app = FastAPI()

class Item(BaseModel):
    name: str
    price: float
    is_offer: Optional[bool] = None

templates = Jinja2Templates(directory='template')


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse('iframe.html', {'request': request})


if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=8000, reload=True)



