"""
Package 안에 만든 파이썬 파일(*.py)을 모듈(module)이라고 부른다.

exam01
간단한 수식

"""

a = 10
b = 20
c = a + b
print(c)
