import folium
from folium import Marker
import pandas as pd
from ipywidgets.embed import embed_minimal_html
from geopy.distance import great_circle


class CountByWGS84:  # WGS84 위경도 좌표 기반 데이터 집계 및 시각화
    def __init__(self, df, lat, lon, dist=1):
        """
        df: 데이터 프레임
        lat: 중심 위도
        lon: 중심 경도
        dist: 기준 거리(km)
        """
        self.df = df
        self.lat = lat
        self.lon = lon
        self.dist = dist

    def filter_by_rectangle(self):
        """
        사각 범위 내 데이터 필터링
        """
        lat_min = self.lat - 0.01 * self.dist
        lat_max = self.lat + 0.01 * self.dist
        lon_min = self.lon - 0.015 * self.dist
        lon_max = self.lon + 0.015 * self.dist

        self.points = [[lat_min, lon_min], [lat_max, lon_max]]
        result = self.df.loc[
            (self.df['lat'] > lat_min) &
            (self.df['lat'] < lat_max) &
            (self.df['lon'] > lon_min) &
            (self.df['lon'] < lon_max)
            ]
        result.index = range(len(result))
        return result

    def filter_by_radius(self):
        """
        반경 범위 내 데이터 필터링
        """
        # 사각 범위 내 데이터 필터링
        tmp = self.filter_by_rectangle()
        # 기준 좌표 포인트
        center = (self.lat, self.lon)
        result = pd.DataFrame()
        for index, row in tmp.iterrows():
            # 개별 좌표 포인트
            point = (row['lat'], row['lon'])
            d = great_circle(center, point).kilometers
            if d <= self.dist:
                result = pd.concat([result, tmp.iloc[index, :].to_frame().T])
        result.index = range(len(result))
        return result

    def plot_by_rectangle(self, df):
        """
        사각 범위 내 데이터 플로팅
        """
        m = folium.Map(location=[self.lat, self.lon], zoom_start=15)
        for idx, row in df.iterrows():
            lat_ = row['lat']
            lon_ = row['lon']
            folium.Marker(location=[lat_, lon_],
                          radius=15,
                          tooltip=row['역사명']).add_to(m)

        folium.Rectangle(bounds=self.points,
                         color='#ff7800',
                         fill=True,
                         fill_color='#ffff00',
                         fill_opacity=0.2).add_to(m)

        return m

    def plot_by_radius(self, df):
        """
        반경 범위 내 데이터 플로팅
        """
        m = folium.Map(location=[self.lat, self.lon], zoom_start=15)

        for idx, row in df.iterrows():
            lat_ = row['lat']
            lon_ = row['lon']
            folium.Marker(location=[lat_, lon_],
                          radius=15,
                          icon=folium.Icon(color='red', icon='train', icon_color='white', prefix='fa'),
                          tooltip=row['역사명']).add_to(m)
        folium.Circle(radius=dist * 1000,
                      location=[lat, lon],
                      color="#ff7800",
                      fill_color='#ffff00',
                      fill_opacity=0.2
                      ).add_to(m)
        return m

park = pd.read_csv('서울시주요공원.csv')
park = park.dropna(axis=0)

apt = pd.read_csv('서울특별시아파트.csv')
apt = apt.dropna(axis=0)

subway = pd.read_csv('서울지하철.csv')
subway = subway.dropna(axis=0)


seoul = (37.566, 126.9784)
# seoul = (126.9784, 37.566)
seoul_map = folium.Map(
    location=seoul,
    radius=1000,
    zoom_start=15)

for _, aptrow in apt.iterrows():
    folium.Marker(location=[aptrow['lat'], aptrow['lng']], popup=aptrow['aptname'],icon=folium.Icon(color='red')).add_to(seoul_map)
    # folium.CircleMarker(location=[aptrow['lat'], aptrow['lng']], color='#fffgg', fill_color='#fffgg').add_to(seoul_map)

for _, row in park.iterrows():
    folium.Marker(location=[row['lat'], row['lng']], popup=row['name'],icon=folium.Icon(color='green', icon='tree-deciduous')).add_to(seoul_map)
    # folium.CircleMarker(location=[row['lat'], row['lng']], radius=100, color='#fffgg', fill_color='#fffgg').add_to(seoul_map)
    # seoul_map.add_child(folium.LatLngPopup())

for _, subwayrow in subway.iterrows():
    folium.Marker(location=[subwayrow['역위도'], subwayrow['역경도']], popup=subwayrow['역사명'],icon=folium.Icon(color='black')).add_to(seoul_map)
    folium.CircleMarker(location=[subwayrow['역위도'], subwayrow['역경도']], color='#fffgg', fill_color='#fffgg').add_to(seoul_map)
# folium.Marker(location=seoul, popup='센터마커', icon=folium.Icon(color='red')).add_to(seoul_map)
# folium.CircleMarker(location=seoul, radius=1000, color='#fffgg', fill_color='#fffgg', popup='반경1km').add_to(seoul_map)


seoul_map.save('../maps/map10.html')
