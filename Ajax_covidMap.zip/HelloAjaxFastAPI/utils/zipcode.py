import pymysql

def get_conn():
    url = '3.34.188.55'
    uid = 'bigdata'
    pwd = 'bigdata2020'
    db = 'bigdata'
    charset = 'utf8'
    conn = pymysql.connect(host=url, user=uid, password=pwd, db=db, charset=charset)
    return conn


def get_sido():
    conn = get_conn()
    cursor = conn.cursor(pymysql.cursors.DictCursor)

    sql = ' select distinct sido from zipcode2013 order by sido '

    param = ()
    cursor.execute(sql, param)
    rows = cursor.fetchall()

    sidos = ''
    for row in rows:
        sidos += row['sido'] + ','

    cursor.close()
    conn.close()

    return sidos


def get_gugun(sido):
    conn = get_conn()
    cursor = conn.cursor(pymysql.cursors.DictCursor)

    sql = 'select distinct gugun from zipcode2013 where sido = %s'

    param = (sido)
    cursor.execute(sql, param)
    rows = cursor.fetchall()

    guguns = ''
    for row in rows:
        guguns += row['gugun'] + ','

    cursor.close()
    conn.close()

    return guguns


def get_dong(sido, gugun):
    conn = get_conn()
    cursor = conn.cursor(pymysql.cursors.DictCursor)

    sql = 'select distinct dong from zipcode2013 where sido = %s and gugun = %s'

    param = (sido, gugun)
    cursor.execute(sql, param)
    rows = cursor.fetchall()

    dongs = ''
    for row in rows:
        dongs += row['dong'] + ','

    cursor.close()
    conn.close()

    return dongs