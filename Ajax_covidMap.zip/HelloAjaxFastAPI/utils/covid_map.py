import pandas as pd
import googlemaps as ggmaps
import gmaps
from ipywidgets.embed import embed_minimal_html

mykey = ''

선별진료소 = pd.read_excel('선별진료소_211028.xls')
선별진료소.head()

# boolean indexing : 객체명[조건식]
city = 선별진료소[선별진료소.시도 == '서울']
city = city.iloc[:, [1,2,3,4,8]]
addr = city.iloc[0, 3]

ggmaps = ggmaps.Client(key=mykey)

info = ggmaps.geocode(addr, language='ko')
info[0]['geometry']['location']

latlng = []
for i in range(len(city['시도'])):
    addr = city.iloc[i, 3]
    info = ggmaps.geocode(addr, language='ko')
    geo = info[0]['geometry']['location']
    latlng.append((geo['lat'], geo['lng']))

hspt_info = []
for i in range(len(city['시도'])):
    info = city.iloc[i, 2]
    hspt_info.append(info)

mysize = { 'width':'1024px', 'height':'768px',
    'border':'1px solid black', 'padding':'10px', 'margin':'10px' }
seoul = (37.566, 126.9784)

gmaps.configure(api_key=mykey)

fig = gmaps.figure(layout=mysize, center=seoul,
                   zoom_level=12)
markers = gmaps.marker_layer(latlng,
               info_box_content=hspt_info)
fig.add_layer(markers)
embed_minimal_html('../template/maps/covid19.html', views=[fig])
