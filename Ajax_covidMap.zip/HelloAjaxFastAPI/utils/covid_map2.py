import pandas as pd
import googlemaps as ggmaps
import gmaps
from ipywidgets.embed import embed_minimal_html

mykey = ''

선별진료소 = pd.read_excel('선별진료소_211028.xls')
선별진료소.head()

sido = '서울'
guguns = ['강남구', '서초구', '구로구']

ggmaps = ggmaps.Client(key=mykey)

for gugun in guguns:
    city = 선별진료소[(선별진료소.시도 == sido) & (선별진료소.시군구 == gugun)]
    city = city.iloc[:, [1,2,3,4,8]]
    city.tail()

    latlng = []
    for i in range(len(city['시도'])):
        addr = city.iloc[i, 3]
        info = ggmaps.geocode(addr, language='ko')
        geo = info[0]['geometry']['location']
        latlng.append((geo['lat'], geo['lng']))

    latlng[:10]

    hspt_info = []
    for i in range(len(city['시도'])):
        info = city.iloc[i, 2]
        hspt_info.append(info)

    hspt_info[:10]

    mysize = { 'width':'1024px', 'height':'768px',
        'border':'1px solid black', 'padding':'10px',
        'margin':'10px' }
    seoul = (37.566, 126.9784)

    fname = '../template/maps/covid19_' + gugun + '.html'
    gmaps.configure(api_key=mykey)

    fig = gmaps.figure(layout=mysize, center=seoul,
                       zoom_level=12)
    markers = gmaps.marker_layer(latlng,
                   info_box_content=hspt_info)
    fig.add_layer(markers)
    embed_minimal_html(fname, views=[fig])