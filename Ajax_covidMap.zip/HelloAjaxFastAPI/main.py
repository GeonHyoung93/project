import uvicorn
from fastapi import FastAPI, Request, Form, Response, Query
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

import utils.zipcode as zip

app = FastAPI()


# 템플릿 폴더 위치 정의
templates = Jinja2Templates(directory='template')

# css, js, img 파일 기준 위치 정의
# app.mount('/static', StaticFiles(directory='../static'), name='static')


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):

    return templates.TemplateResponse('ajax.html', {'request': request})



@app.get("/map", response_class=HTMLResponse)
async def index(request: Request):

    return templates.TemplateResponse('map.html', {'request': request})


@app.get("/hello")
async def hello():

    return "hello, ajax!!"


@app.get("/dongs")
async def dongs():

    with open('utils/dong.txt', encoding='UTF-8') as f:
        dongs = f.read()

    return Response(content=dongs, media_type="text/plain")

@app.get("/sido")
async def sido():

    sidos = zip.get_sido()

    return Response(content=sidos, media_type="text/plain")

@app.get("/gugun")
async def gugun(sido: str = Query(...)):

    guguns = zip.get_gugun(sido)

    return Response(content=guguns, media_type="text/plain")

@app.get("/dong")
async def dong(sido: str = Query(...), gugun: str = Query(...)):

    dongs = zip.get_dong(sido, gugun)

    return Response(content=dongs, media_type="text/plain")

@app.get("/covid_seoul")
async def covid_seoul(request: Request):

    return templates.TemplateResponse('maps/covid19.html', {'request': request})


@app.get("/covid_map")
async def covid_seoul(request: Request, gugun: str = Query(...)):
    map = 'maps/covid19_' + gugun + '.html'
    return templates.TemplateResponse(map, {'request': request})


if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=8000, reload=True)
