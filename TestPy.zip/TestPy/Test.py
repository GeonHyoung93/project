import time
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

url = 'https://map.kakao.com/'

# headless를 위한 설정(브라우저 띄우는 과정을 생략하기 위해)
options = Options()
#options.add_argument('--headless')


# 크롬 웹드라이버 설정 -> webdriver 실행
path = r'C:\Program Files\Google\Chrome\Application\chromedriver.exe'
chrome = webdriver.Chrome(executable_path=path)    # 브라우저가 뜨는 것이 보임
#chrome = webdriver.Chrome(executable_path=path, options=options)

# 소스 읽어오기
chrome.get(url)

# 소스가 다 로딩될 때까지 2초 정도 대기
chrome.implicitly_wait(2)
time.sleep(2)   # 작업을 의도적으로 지연 (2초동안) - 사람이 작업하는 듯

chrome.find_element(By.XPATH, './/ul[@class="menu"]/li[@id="search.tab2"]/a[@class="mainmenutab"]').click()
# time.sleep(2)




# startPoint = "서울시 구로구 구로동 188-25"
# #chrome.find_element(By.XPATH, '//*[@id="container"]/shrinkable-layout/div/app-base/search-input-box/div/div[1]/div/label').click()
# # chrome.find_element(By.XPATH, '//*[@id="directionStart0"]').send_keys(startPoint)
# chrome.find_element(By.XPATH, '//*[@id="search.keyword.query"]').send_keys(startPoint)
# time.sleep(1)
